package com.example.proyectotallerinformatica;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;

public class Arreglar extends AppCompatActivity {

    Spinner sp;
    SQLiteHelper sqliteHelper;
    SQLiteDatabase db;

    Button btnEnviar;

    EditText cajaNombreTecnico, cajaDetalles, cajaPorcentaje;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.arreglar);

        sp = findViewById(R.id.spinnerAverias);
        btnEnviar = findViewById(R.id.btnEnviar);
        cajaNombreTecnico = findViewById(R.id.cajaNombreTecnico);
        cajaDetalles = findViewById(R.id.cajaDetalles);
        cajaPorcentaje = findViewById(R.id.cajaPorcentaje);

        sqliteHelper = new SQLiteHelper(this);
        db = sqliteHelper.getReadableDatabase();

        rellenarSpinner();
        crearParte();
    }

    private void rellenarSpinner() {

        // Hacemos una consulta sobre la base de datos Averias y obtenemos la id y el nombre del ordenador
        Cursor c = db.rawQuery("SELECT id, modelo, descripcion FROM Averias", null);
        if (c.moveToFirst()) {
            do {
                // Creamos un array con los datos obtenidos
                String[] datos = {"ID: " + c.getString(0) + " Modelo: " + c.getString(1) + " Descripción: " + c.getString(2)};

                // Rellenamos el spinner
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, datos);
                sp.setAdapter(adapter);
            } while (c.moveToNext());
        }

        c.close();
    }

    private void crearParte() {
        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Date fecha = new Date();

                // Obtenemos el id del ordenador seleccionado en el spinner
                String itemSeleccionado = sp.getSelectedItem().toString();
                String[] partes = itemSeleccionado.split(" ");
                String idSeleccionado = partes[1];

                // Comprobamos que no se haya creado un parte con ese id, si se ha creado se actualiza
                Cursor c = db.rawQuery("SELECT idAveria FROM estadoAverias WHERE idAveria = ?", new String[]{idSeleccionado});
                if (c.moveToFirst()) {
                    ContentValues cv = new ContentValues();
                    cv.put("idAveria", idSeleccionado);
                    cv.put("nombreTecnico", cajaNombreTecnico.getText().toString());
                    cv.put("detalles", cajaDetalles.getText().toString());
                    cv.put("porcentaje", cajaPorcentaje.getText().toString());
                    cv.put("fecha", fecha.toString());

                    if (cajaDetalles.getText().toString().isEmpty() || cajaNombreTecnico.getText().toString().isEmpty() || cajaPorcentaje.getText().toString().isEmpty()) {
                        Toast.makeText(Arreglar.this, "Rellena todos los campos", Toast.LENGTH_SHORT).show();
                    } else {
                        // Si los campos no estan vacios actualizamos con el nuevo COntentValues
                        db.update("estadoAverias", cv, "idAveria = ?", new String[]{idSeleccionado});
                        Toast.makeText(Arreglar.this, "Parte actualizado correctamente", Toast.LENGTH_SHORT).show();
                    }


                } else {
                    ContentValues cv = new ContentValues();
                    cv.put("idAveria", idSeleccionado);
                    cv.put("nombreTecnico", cajaNombreTecnico.getText().toString());
                    cv.put("detalles", cajaDetalles.getText().toString());
                    cv.put("porcentaje", cajaPorcentaje.getText().toString());
                    cv.put("fecha", fecha.toString());

                    if (cajaDetalles.getText().toString().isEmpty() || cajaNombreTecnico.getText().toString().isEmpty() || cajaPorcentaje.getText().toString().isEmpty()) {
                        Toast.makeText(Arreglar.this, "Rellena todos los campos", Toast.LENGTH_SHORT).show();
                    } else {
                        db.insert("estadoAverias", null, cv);
                        Toast.makeText(Arreglar.this, "Parte creado correctamente", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
