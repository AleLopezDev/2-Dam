package com.example.proyectotallerinformatica;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ConsultarAverias extends AppCompatActivity {

    Button btnConsultar;
    EditText cajaTelefono;
    SQLiteHelper sqliteHelper;
    SQLiteDatabase db;

    ProgressBar progressBar;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.consultaraveria);
        btnConsultar = findViewById(R.id.btnConsultar);
        cajaTelefono = findViewById(R.id.cajaTelefono);
        progressBar = findViewById(R.id.progressBar);

        sqliteHelper = new SQLiteHelper(this);
        db = sqliteHelper.getReadableDatabase();

        realizarConsulta();
    }

    public void realizarConsulta() {
        btnConsultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int id = 0;

                Cursor c1 = db.rawQuery("Select id from Averias where telefono = '" + cajaTelefono.getText().toString() + "'", null);
                if (c1.moveToFirst()) {
                    do {
                        id = c1.getInt(0);
                    } while (c1.moveToNext());
                }

                Cursor c2 = db.rawQuery("Select * from estadoAverias where idAveria = '" + id + "'", null);
                if (c2.moveToFirst()) {
                    do {
                        progressBar.setProgress(Integer.parseInt(c2.getString(3)));
                    } while (c2.moveToNext());
                } else {
                    Toast.makeText(getApplicationContext(), "No se han realizado reparaciones en tu ordenador", Toast.LENGTH_SHORT).show();
                }


                // Realiza una consulta
                Cursor c = db.rawQuery("SELECT * FROM Averias WHERE telefono = '" + cajaTelefono.getText().toString() + "'", null);
                if (c.moveToFirst()) {
                    do {
                        Toast.makeText(getApplicationContext(), "Nombre: " + c.getString(0) + " Descripción: " + c.getString(1) + "Ordenador: " + c.getString(2), Toast.LENGTH_SHORT).show();
                    } while (c.moveToNext());
                }
            }
        });
    }
}
