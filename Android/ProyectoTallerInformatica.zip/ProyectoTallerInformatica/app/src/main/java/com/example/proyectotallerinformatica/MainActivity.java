package com.example.proyectotallerinformatica;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnReparar, btnConsultar, btnArreglar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnReparar = findViewById(R.id.btnReparar);
        btnConsultar = findViewById(R.id.btnConsultar);
        btnArreglar = findViewById(R.id.btnArreglar);

        addListeners();

    }

    protected  void addListeners(){
        btnReparar.setOnClickListener(new ListenerPinchar(MainActivity.this));
        btnConsultar.setOnClickListener(new ListenerPinchar(MainActivity.this));
        btnArreglar.setOnClickListener(new ListenerPinchar(MainActivity.this));
    }
}