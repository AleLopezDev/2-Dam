package com.example.proyectotallerinformatica;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;

public class Reparar extends AppCompatActivity {

    Spinner sp;
    Button btnGuardar;
    SQLiteHelper sqliteHelper;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reparar);
        sp = findViewById(R.id.spinner);
        btnGuardar = findViewById(R.id.buttonGuardar);

        sqliteHelper = new SQLiteHelper(this);
        db = sqliteHelper.getWritableDatabase();

        if (db != null) {
            Toast.makeText(this, "Base de datos creada correctamente", Toast.LENGTH_SHORT).show();
        }

        rellenarSpinner();
        guardarAveria();
    }

    private void rellenarSpinner() {
        String[] ordenadores = {"Omen HP", "Asus 4", "LG 2", "MacBook Pro", "MacBook Air", "Samsung", "Legion BG"};

        // Rellenamos el spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, ordenadores);
        sp.setAdapter(adapter);
    }

    private void guardarAveria() {
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EditText cajaDescripcion = findViewById(R.id.cajaDetalles);
                EditText cajaNombre = findViewById(R.id.cajaNombre);
                EditText cajaTelefono = findViewById(R.id.cajaTelefono);

                Date fecha = new Date();

                // Verifica si el nombre ya existe en la base de datos
                Cursor cursor = db.rawQuery("SELECT * FROM Averias WHERE telefono = ?", new String[] {cajaTelefono.getText().toString()});
                if (cursor.moveToFirst()) {
                    Toast.makeText(Reparar.this, "El telefono ya existe en la base de datos", Toast.LENGTH_SHORT).show();
                    cursor.close();
                    return;
                }
                cursor.close();

                // Realiza un insert
                ContentValues valores = new ContentValues();
                valores.put("nombre", cajaNombre.getText().toString().toLowerCase());
                valores.put("telefono", cajaTelefono.getText().toString());
                valores.put("modelo", sp.getSelectedItem().toString());
                valores.put("descripcion", cajaDescripcion.getText().toString());
                valores.put("fecha", fecha.toString());

                if(cajaNombre.getText().toString().isEmpty() || cajaDescripcion.getText().toString().isEmpty() || cajaTelefono.getText().toString().isEmpty()){
                    Toast.makeText(Reparar.this, "Rellena todos los campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                db.insert("Averias", null, valores);

                Toast.makeText(Reparar.this, "Avería enviada a nuestros técnicos", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
