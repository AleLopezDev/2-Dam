package com.example.proyectotallerinformatica;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLiteHelper extends SQLiteOpenHelper {

    private String sqlCrear = "CREATE TABLE Averias (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT, telefono TEXT , modelo TEXT, descripcion TEXT, fecha DATE)";
    private String sqlCrearSegundaTabla = "CREATE TABLE estadoAverias (idAveria INTEGER PRIMARY KEY AUTOINCREMENT, nombreTecnico TEXT, detalles TEXT , porcentaje TEXT, fecha DATE)";
    private static final String DATABASE_NAME = "TallerInformatica.db";
    private static final int DATABASE_VERSION = 1;

    public SQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(sqlCrear);
        db.execSQL(sqlCrearSegundaTabla);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Averias");
        db.execSQL(sqlCrear);

        db.execSQL("DROP TABLE IF EXISTS estadoAverias");
        db.execSQL(sqlCrearSegundaTabla);
    }
}
