package com.example.proyectotallerinformatica;

import android.content.Context;
import android.content.Intent;
import android.view.View;

public class ListenerPinchar implements View.OnClickListener {

    Context ctx;
    public ListenerPinchar(MainActivity mainActivity) {
        this.ctx = mainActivity;
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.btnReparar:
                Intent intent = new Intent(ctx, Reparar.class);
                ctx.startActivity(intent);
                break;
            case R.id.btnConsultar:
                Intent intent2 = new Intent(ctx, ConsultarAverias.class);
                ctx.startActivity(intent2);
                break;
            case R.id.btnArreglar:
                Intent intent3 = new Intent(ctx, Arreglar.class);
                ctx.startActivity(intent3);
                break;
        }
    }
}
